package models;



public interface Comparable {
    public int compareTo (Product other);
}
