package models.enums;

public enum UserType{

    Costumer,
    Store;

}
