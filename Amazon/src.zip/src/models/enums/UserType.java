package models.enums;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum UserType{

    Costumer,
    Store;

}
